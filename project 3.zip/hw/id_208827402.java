package hw;

import java.util.Scanner;

public class id_208827402 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int button;// control for selection

		Scanner input = new Scanner(System.in);
		System.out.println("plese enther which program you would like to run");
		System.out.println("to run a program that checks if 2 arrays are 1 digit decentered press 1");
		System.out.println(
				"to run a program that changes small letters to capital letters in an enclosed area of an array press 2");
		System.out.println("to run a program that finds the same values in 2 arrays press 3");
		System.out.println("to run a program that prints colums for array values press 4");
		System.out.println("to run a program that multiplies using arrays, press 5");
		System.out.println("to run a program that finds the highest number in a Matrix shell press 6");
		System.out.println("to run a program that writes numbers in a slithering pattern press 7");
		System.out.println("to run a program that XXXXX press 8");
		button = input.nextInt();

		switch (button) {
		case 1:
			System.out.println(circledArray());
			break;
		case 2:
			char[] arr1 = new char[] { 'a', 'f', 'g', 'K', 'e', 'r', 't', 'M', 'h' };// for question#2
			System.out.println(capitalMorpher(arr1));
			break;
		case 3:
			int[] arr2 = new int[] { 1, 2, 3, 5, 8, 10 };
			int[] arr3 = new int[] { 2, 3, 4, 5, 9, 10 };
			arrayValues(arr2, arr3); // for question 3

			break;
		case 4:
			int[] value = new int[] { 4, 2, 6, 5 };
			printStars(value);

			break;
		case 5:
			int[] num1 = new int[] { 7, 2, 3 };
			int[] num2 = new int[] { 2, 5 };
			multiplyNumbers(num1, num2);
			break;
		case 6:
			int[][] matrix = new int[][] { { 8, 5, 2, 77 }, { 44, 65, 98, 54 }, { 100, 2, 5, 33 }, { 6, 55, 77, 54 },
					{ 1, 22, -8, 5 } };

			System.out.println(findArrayValue(matrix));
			break;
		case 7:
			int[][] snake = new int[5][7];
			snakeMatrix(snake);
			break;
		case 8:
			char[][] road = new char[][] { { 'a', 'a', 'a', 'a', 'a', '|' }, 
										   { 'a', 'a', 'a', 'a', '|', '|' },
										   { 'a', 'a', '|', '-', '-', '-' }, 
										   { 'a', 'a', '|', 'a', 'a', 'a' } };
			       System.out.println(roadMap(road));
			break;

		default:
			break;
		}
		input.close();

	}

	public static boolean circledArray() {
		int[] arr1 = new int[] { 9, 3, 4, 6, 8 };
		int[] arr2 = new int[] { 8, 9, 3, 4, 6 };

		if (arr1[arr1.length - 1] != arr2[0])// if the first number in the first array and the second in the second
												// aren't equal
			return false;
		for (int i = 0; i < arr2.length - 1; i++) {
			if (arr1[i] != arr2[i + 1])// checking if int in array 1 equal the one after in array 2
				return false;
		}
		return true;

	}

	public static char[] capitalMorpher(char[] arr1) {

		int startIndex = 0;
		int lastIndex = 0;
		int i;
		for (i = 0; i < arr1.length; i++) {
			if (arr1[i] >= 'A' && arr1[i] <= 'Z') {// find first capital letter
				startIndex = i;
				break;// found capital, stops
			}
		}
		for (int j = i + 1; j < arr1.length; j++) {
			if (arr1[j] >= 'A' && arr1[j] <= 'Z') {// find second capital letter
				lastIndex = j;
				break;// found capital, stops
			}
		}
		for (i = startIndex + 1; i < lastIndex; i++) {// flip the letters in between
			arr1[i] = (char) (arr1[i] - 'a' + 'A');
		}

		return arr1;
	}

	public static int[] arrayValues(int[] arr1, int[] arr2) {
		int count = 0;// arr3 value counter
		int i = 0;// array1 value
		int j = 0;// array2 value
		int[] arr4;
		while (i < arr1.length && j < arr2.length) {// checking individual digits in each array against each other
			if (arr1[i] == arr2[j]) {// checking arr1 at place [i] against arr2 at place[j]
				count++;// raising arr3 value counter
				i++;
				j++;
			} else if (arr1[i] < arr2[j])
				i++;
			else
				j++;
		}
		if (i != arr1.length) {// if the second array has more digits
			int temp = i;
			while (temp < arr1.length) {
				if (arr1[temp] == arr2[arr2.length - 1]) {
					count++;
				}
				temp++;
			}
		}
		if (j != arr2.length) {// if the first array has more digits
			int temp = j;
			while (j < arr2.length) {
				if (arr2[temp] == arr1[arr1.length - 1]) {
					count++;
				}
				temp++;
			}
		}
		int[] arr3 = new int[count];// define arr3
		int k = 0;
		i = 0;
		j = 0;
		while (i < arr1.length && j < arr2.length) {// filling in arr3
			if (arr1[i] == arr2[j]) {
				arr3[k] = arr1[i];
				i++;
				j++;
				k++;
			} else if (arr1[i] < arr2[j])
				i++;
			else
				j++;
		}
		if (i != arr1.length) {
			while (i < arr1.length) {
				if (arr1[i] == arr2[arr2.length - 1]) {
					arr3[k] = arr1[i];
					k++;
				}
				i++;
			}
		}
		if (j != arr2.length) {
			while (j < arr2.length) {
				if (arr2[j] == arr1[arr1.length - 1]) {
					arr3[k] = arr2[j];
					k++;
				}
				j++;
			}
		}
		printArray(arr3);
		return arr3;
	}

	public static void printArray(int[] arr3) {// print the array values
		for (int i = 0; i < arr3.length; i++)
			System.out.print(arr3[i] + " ");
	}

	public static void printStars(int[] value) {
		int max = 0;

		for (int i = 0; i < value.length; i++) {// finding starting row
			if (value[i] > max)
				max = value[i];
		}
		for (int i = 0; i < max; i++) {// printing the column of asterisks for each value
			for (int j = 0; j < value.length; j++) {
				if (i >= max - value[j])
					System.out.print("*  ");
				else
					System.out.print("   ");

			}
			System.out.println("");// going down a row
		}
		for (int i = 0; i < value.length * 3; i++) {// print the floor
			System.out.print("-");
		}
		System.out.println("");// print int values
		for (int i = 0; i < value.length; i++) {
			System.out.print(value[i] + "  ");
		}
		System.out.println("");
	}

	public static void multiplyNumbers(int[] num1, int[] num2) {
		int newArrLength = num1.length + num2.length;// static length of array
		int[][] multiAdder = new int[num2.length][newArrLength];// multiplication of arrays
		int[] resArray = new int[newArrLength];// setting length of result array: sum of products

		for (int i = num2.length - 1, k = 0; i >= 0; i--, k++) {// feel in matrix of long multiplication
			int carry = 0;// carry multiplication overflow
			for (int j = num1.length - 1; j >= 0; j--) {

				multiAdder[k][j + i + 1] = (num1[j] * num2[i] + carry) % 10;// static num 2 multiplied by all num 1
				carry = (carry + num1[j] * num2[i]) / 10;
				System.out.print(multiAdder[k][j + i + 1]);

			}
			System.out.println("");
			if (carry != 0) {
				multiAdder[k][i] = carry;// TODO check i
			}

		}

		int carry = 0;
		for (int i = newArrLength - 1; i >= 0; i--) { // number of columns

			int sum = 0;
			for (int j = 0; j < num2.length; j++) { // number of rows
				sum += multiAdder[j][i];

			}
			resArray[i] = (sum + carry) % 10;
			carry = (sum + carry) / 10;
		}
		// resArray[0] = carry;
		if (resArray[0] == 0) {
			resArray[0] = carry; // TODO
		}

		printArray(resArray);
	}

	public static int findArrayValue(int[][] matrix) {
		// create a function loop to check highest in first row and last row
		int max = 0;// find max value
		for (int i = 0; i < matrix.length; i++) {// run through rows
			for (int j = 0; j < matrix[i].length; j++) {// run through columns
				if (i == 0 || i == matrix.length - 1 || j == 0 || j == matrix[i].length - 1) {// if outer shell
					if (matrix[i][j] > max)
						max = matrix[i][j];

				}

			}
		}
		// create a function loop to check in middle rows first and last interval
		return max;
	}
	public static int[][] snakeMatrix(int[][] snake) {
		int num = 1;// value of matrix [i][j]
		boolean flag = false; // 0 start from 0, 1 start from n-1
		for (int j = snake[0].length - 1; j >= 0; j--) {// start with column

			int i;
			if (flag == false) {
				i = 0;
				for (; i < snake.length; i++) {
					snake[i][j] = num;
					num++;
				}
			} else {
				i = snake.length - 1;
				for (; i >= 0; i--) {
					snake[i][j] = num;
					num++;
				}
			}
			flag ^= true;
		}
		printMatrix(snake);
		return snake;
		//
	}

	public static void printMatrix(int[][] snake) {
		for (int i = 0; i < snake.length; i++) {
			for (int j = 0; j < snake[i].length; j++)
				System.out.print(snake[i][j] + "    ");
			System.out.println();

		}
	}
	public static boolean roadMap(char[][] road) {
		int i = 0;
		int j = road[0].length - 1;
		while (true) {
			if (i == road.length - 1) {
				if (road[i][j] == '|')
					return true;
				else
					return false;
			} else if (road[i][j] == '|') {
				if (i + 1 <= road.length - 1)
					i++;
			} else if (road[i][j] == '-') {
				if (j - 1 >= 0)
					j--;
				else
					return false;
			} else
				return false;
		}
	}

}